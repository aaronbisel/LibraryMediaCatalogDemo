<?php
	function displayAbout()
	{
		echo("");
?>
				
	<center><h1>Library Media Catalog - Basic Demo</h1></center>							
		
<?php
	}
?>
	